<?php

namespace Aurora\Modules\Contacts\Enums;

class FileType extends \Aurora\System\Enums\AbstractEnumeration
{
	const CSV = 'csv';
	const VCF = 'vcf';
}	

